#include"ImagePGM.h"


ImagePGM::ImagePGM(){

}

ImagePGM::~ImagePGM(){

}

void ImagePGM::resize(int rows,int cols){
	//TODO: falta implementarlo
}

void ImagePGM::setPixel(int row,int col,int value){
	//TODO: falta implementarlo
}
