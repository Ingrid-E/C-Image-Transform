#include"ImagePPM.h"


ImagePPM::ImagePPM(){

}

ImagePPM::~ImagePPM(){

}

void ImagePPM::resize(int rows, int cols){
	//TODO: falta implementarlo
}

void ImagePPM::setPixel(int row,int col,int value){
	//TODO: falta implementarlo
}