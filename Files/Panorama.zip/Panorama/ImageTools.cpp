#include "ImageTools.h"

ImageTools::ImageTools(){

}

ImageTools::~ImageTools(){

}


int ImageTools:: toGray(){
	//TODO: falta implementarlo
}
int ImageTools:: toNegative(){
	//TODO: falta implementarlo
}
int ImageTools:: toSephia(){
	//TODO: falta implementarlo
}